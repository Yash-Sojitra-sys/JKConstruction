import React from 'react';

const ProjectsSection: React.FC = () => {
  const projects = [
    {
      title: "Metro Rail Infrastructure",
      description: "Complete metro rail construction including tunneling, station development, and electrical systems for urban transportation networks.",
      image: "https://images.pexels.com/photos/378570/pexels-photo-378570.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
    },
    {
      title: "Smart City Development",
      description: "Integrated smart city solutions with IoT infrastructure, sustainable buildings, and modern urban planning for future-ready communities.",
      image: "https://images.pexels.com/photos/2219024/pexels-photo-2219024.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
    },
    {
      title: "Highway Construction",
      description: "Multi-lane highway construction with advanced drainage systems, safety barriers, and sustainable road materials for long-lasting infrastructure.",
      image: "https://images.pexels.com/photos/3862600/pexels-photo-3862600.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
    },
    {
      title: "Residential Complex",
      description: "Modern residential towers with eco-friendly design, smart home integration, and community amenities for comfortable urban living.",
      image: "https://images.pexels.com/photos/280229/pexels-photo-280229.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
    },
    {
      title: "Industrial Manufacturing Plant",
      description: "State-of-the-art manufacturing facility with automated systems, sustainable energy solutions, and optimized workflow design for maximum efficiency.",
      image: "https://images.pexels.com/photos/1216589/pexels-photo-1216589.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
    },
    {
      title: "Bridge Engineering",
      description: "Cable-stayed bridge construction with advanced engineering solutions, seismic resistance, and aesthetic architectural design.",
      image: "https://images.pexels.com/photos/416978/pexels-photo-416978.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
    },
    {
      title: "Airport Terminal Expansion",
      description: "Modern airport terminal with passenger-centric design, advanced security systems, and sustainable construction practices for enhanced travel experience.",
      image: "https://images.pexels.com/photos/2026324/pexels-photo-2026324.jpeg?auto=compress&cs=tinysrgb&w=800&h=600&fit=crop"
    }
  ];

  return (
    <section className="py-20 px-6 bg-gray-50">
      <div className="max-w-5xl mx-auto">
        <div className="mb-12">
          <h2 className="text-4xl md:text-5xl font-bold text-blue-600 mb-4 text-left">Projects</h2>
        </div>
        
        {/* First Row - 3 Projects */}
        <div className="grid grid-cols-1 md:grid-cols-3 gap-2 mb-2">
          {projects.slice(0, 3).map((project, index) => (
            <div key={index} className="relative group cursor-pointer overflow-hidden rounded-lg">
              <img 
                src={project.image}
                alt={project.title}
                className="w-full h-96 object-cover group-hover:scale-125 transition-all duration-[5000ms] ease-linear transform-gpu"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white group-hover:opacity-0 transition-opacity duration-300">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
              </div>
              
              {/* Hover Description */}
              <div className="absolute inset-0 bg-gradient-to-t from-blue-700/80 via-blue-500/40 via-blue-300/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end">
                <div className="p-6 text-white transform translate-y-8 group-hover:translate-y-0 transition-transform duration-500 ease-out">
                  <h3 className="text-2xl font-bold mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-150">{project.title}</h3>
                  <p className="text-sm leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-300">{project.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
        
        {/* Second Row - 4 Projects */}
        <div className="grid grid-cols-1 md:grid-cols-4 gap-2">
          {projects.slice(3, 7).map((project, index) => (
            <div key={index + 3} className="relative group cursor-pointer overflow-hidden rounded-lg">
              <img 
                src={project.image}
                alt={project.title}
                className="w-full h-96 object-cover group-hover:scale-125 transition-all duration-[5000ms] ease-linear transform-gpu"
              />
              <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent"></div>
              <div className="absolute bottom-4 left-4 text-white group-hover:opacity-0 transition-opacity duration-300">
                <h3 className="text-xl font-bold mb-2">{project.title}</h3>
              </div>
              
              {/* Hover Description */}
              <div className="absolute inset-0 bg-gradient-to-t from-blue-700/80 via-blue-500/40 via-blue-300/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-500 flex items-end">
                <div className="p-6 text-white transform translate-y-8 group-hover:translate-y-0 transition-transform duration-500 ease-out">
                  <h3 className="text-2xl font-bold mb-4 opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-150">{project.title}</h3>
                  <p className="text-sm leading-relaxed opacity-0 group-hover:opacity-100 transition-opacity duration-500 delay-300">{project.description}</p>
                </div>
              </div>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
};

export default ProjectsSection;